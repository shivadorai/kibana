
<!--
If you are filing a bug report, please remove the below feature
request block and provide responses for all of the below items.

NOTE: The scripts directory of this repository contains a python script, as well as an elasticsearch mapping json
file, that can be used to generate a set of test data. This is the test data that is used to test the plugin. Feel free
to use these scripts to generate test data that you can then report defects against. This will avoid having you to expose
your own internal data for the issue report. If the test scripts are missing an edge case, please indicate this as part of your issue.
-->

**Plugin version**:

**Kibana version**:

**Plugins installed**:

**Description of the problem including expected versus actual behavior**:

**Steps to reproduce**:
 1.
 2.
 3.

**Errors in browser console (if relevant)**:

**Provide logs and/or server output (if relevant)**:

**If using docker, include your docker file**:

<!--
If you are filing a feature request, please remove the above bug
report block and provide responses for all of the below items.
-->

**Describe the feature**:
