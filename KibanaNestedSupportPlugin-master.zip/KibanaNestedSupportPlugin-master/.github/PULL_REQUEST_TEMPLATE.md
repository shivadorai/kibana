<!--
Thank you for your interest in and contributing to this Kibana plugin! Please answer the 
following questions:
-->

**Link to issue:**

**Port to other versions?**

**Describe the changes in the pull request:**


