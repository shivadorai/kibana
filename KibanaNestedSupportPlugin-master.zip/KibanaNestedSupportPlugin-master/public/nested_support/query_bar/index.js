import './lib/queryLanguages';
import './directive/query_bar';